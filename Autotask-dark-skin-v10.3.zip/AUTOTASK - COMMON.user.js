// ==UserScript==
// @name         AUTOTASK - COMMON
// @namespace    https://uk2.autotask.net/Mvc/Framework/Navigation.mvc/Landing
// @version      10.3
// @description  Dark Skin
// @author       schwarzerBengel
// @match        https://uk2.autotask.net/*
// @grant        none
// ==/UserScript==

/*
- DATE UPDATE -
2018.12.10

- NAMESPACE -

You must change the address according to your location.

Americ East: ww3.autotask.net
Americ East 2: ww14.autotask.net
America West: ww5.autotask.net
America West 2: ww15.autotask.net
UK (English Europe and Asia): ww4.autotask.net
UK 2 (English Europe and Asia): ww16.autotask.net
Australia / New Zealand: ww6.autotask.net
German (Deutsch: ww7.autotask.net
Spanish (Español): ww12.autotask.net

- SYNTAX -
addGlobalStyle(' { }');

- COLORS -
Background color : #1C1C1C
Grey : #4B4B4B
Pale grey : #323232
Pale yellow : WHEAT
*/

function addGlobalStyle(css) {
    var head, style;
    head = document.getElementsByTagName('head')[0];
    if (!head) { return; }
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = css;
    head.appendChild(style);
}

// BAR
addGlobalStyle('body.TechTheme .ThemePrimaryColor { background: #4B4B4B; color: WHEAT; }');
addGlobalStyle('.HeaderRow { background: #4B4B4B; }');
addGlobalStyle('.HeaderRow span { color: WHEAT; }');

// TABLEAUX
addGlobalStyle('.Grid > .Body > .Scrolling > table > tbody > tr > td { border: solid 1px BLACK; border-left-color: BLACK; border-right-color: BLACK; }');
addGlobalStyle('body.TechTheme .Grid > .Header, body .DashboardTab.TechTheme .Grid > .Header, body.TechTheme .Table .HeaderContainer, body .DashboardTab.TechTheme .Table .HeaderContainer { background: #4B4B4B; color: BLACK; text-align:center; }');
addGlobalStyle('body.TechTheme .Grid > .Header > table > tbody > tr > td, body .DashboardTab.TechTheme .Grid > .Header > table > tbody > tr > td, body.TechTheme .Table .HeaderContainer td, body .DashboardTab.TechTheme .Table .HeaderContainer td { color: WHITE; }');
addGlobalStyle('body.Trebuchet, body.Trebuchet input[type="text"], body.Trebuchet select, body.Trebuchet textarea { color: white; }');

// OVERLAY
addGlobalStyle('#SiteNavigationBar .ContextOverlay { border: 1px solid BLACK; }');
addGlobalStyle('.ContextOverlay { background: #1C1C1C !important; border: 1px solid BLACK; color: WHEAT;}');
addGlobalStyle('#SiteNavigationBar .Guide > .ButtonContainer { background: #1C1C1C; }');
addGlobalStyle('.Guide .Button.GuideNavigation.SelectedState { background: #4B4B4B; color: WHITE; }');
addGlobalStyle('.Guide .Button.GuideNavigation { background: #1C1C1C; color: WHEAT; }');
addGlobalStyle('.ContextOverlay .Group > .Heading > .Text { color: RED; }');
addGlobalStyle('.ContextOverlay .Group > .Heading { border-bottom: 1px solid RED; }');
addGlobalStyle('a.Button { color: WHITE; }');
addGlobalStyle('#SiteNavigationBar .ContextOverlay > .Content .Title { color: WHEAT; }');
addGlobalStyle('.SiteNavigationFooterSeparator { border-botto: 1px solid RED; }');
addGlobalStyle('.ContextOverlay > .Arrow { border: 9px solid BLACK; }');
addGlobalStyle('.ContextOverlay .Group > .Content > a.Button.HoverState, .ContextOverlay .Group > .Content > a.Button.SelectedState { background: #4B4B4B; }');
addGlobalStyle('.Item[data-is-targeted="true"] { background-color: #4B4B4B !important; }');

// PAGE CONTACTS - COMPANY SHEET
addGlobalStyle('.ButtonBar { background: #1C1C1C !important; }');
addGlobalStyle('.ButtonBar ul li a, .ButtonBar ul li a:visited, .contentButton a, .contentButton a:link, .contentButton a:visited, a.buttons, input.button, .ButtonBar ul li a:visited { background: #1C1C1C !important; }');
addGlobalStyle('.DivScrollingContainer { background: #1C1C1C !important; }');
addGlobalStyle('.grid thead td { background: #4B4B4B !important; color: BLACK; }');
addGlobalStyle('.grid { background: #1C1C1C !important; }');
addGlobalStyle('.grid .selected { background-color: #4B4B4B !important; }');
addGlobalStyle('.grid tbody td { color: #C5C5C5 !important; }');
addGlobalStyle('body { background: #1C1C1C !important; }');

// TREATMENT TICKETS
addGlobalStyle('.YellowHeader { color: WHEAT !important; }');
addGlobalStyle('input[type="text"], select, textarea { background: #4B4B4B; color: WHITE !important; }');
addGlobalStyle('.NavigationTabBar li.Selected { background: #1C1C1C; border-bottom: solid 1px #1C1C1C;  }');
addGlobalStyle('.NavigationTabBar li { background: none !important; }');
addGlobalStyle('.CriteriaSection.Collapsed, .CriteriaSection.Calendar.Collapsed { background: #1C1C1C !important; }');
addGlobalStyle('.CriteriaSection > .Heading { background: #1C1C1C !important; }');

// MESSAGE BAR
addGlobalStyle('.MessageBar.Alert { background: #750009 !important; color: WHITE; }');
addGlobalStyle('.MessageBar.Alert > .IconContainer { background: #750009 !important; }');

// BOXES OF DIALOGUES
addGlobalStyle('.Dialog > div { background: #1C1C1C !important; color: WHITE; }');
addGlobalStyle('a.Button { background: BLACK; !important;      }');

// BACKGROUND
addGlobalStyle('body.CarbonFiber > #WorkspaceContainer { background-image: url("https://wallpapers.wallhaven.cc/wallpapers/full/wallhaven-459790.jpg") !important; }');
