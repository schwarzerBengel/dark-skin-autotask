// ==UserScript==
// @name         AUTOTASK - DASHBORD
// @namespace    https://uk2.autotask.net/Mvc/Framework/Navigation.mvc/Landing
// @version      10.3
// @description  Dark Skin
// @author       schwarzerBengel
// @match        https://uk2.autotask.net/Mvc/Framework/Navigation.mvc/Landing
// ==/UserScript==


/*
- DATE UPDATE -
2018.12.10

- NAMESPACE -

You must change the address according to your location.

Americ East: ww3.autotask.net
Americ East 2: ww14.autotask.net
America West: ww5.autotask.net
America West 2: ww15.autotask.net
UK (English Europe and Asia): ww4.autotask.net
UK 2 (English Europe and Asia): ww16.autotask.net
Australia / New Zealand: ww6.autotask.net
German (Deutsch: ww7.autotask.net
Spanish (Español): ww12.autotask.net

- SYNTAX -
addGlobalStyle(' { }');

- COLORS -
Background color : #1C1C1C
Grey : #4B4B4B
Pale grey : #323232
Pale yellow : WHEAT
*/

function addGlobalStyle(css) {
    var head, style;
    head = document.getElementsByTagName('head')[0];
    if (!head) { return; }
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = css;
    head.appendChild(style);
}

// BAR OF MENUS
addGlobalStyle('#SiteNavigationBar { background: #1C1C1C; }');
addGlobalStyle('#SiteNavigationBar > .Left, #SiteNavigationBar > .Right { background-color: #1C1C1C; }');
addGlobalStyle('#SiteNavigationBar > .Left > .Button.Logo { border: 1px solid #1C1C1C; background: #1C1C1C; }');
addGlobalStyle('#SiteNavigationBar .ButtonGroup { background: #1C1C1C; }');
addGlobalStyle('#SiteNavigationBar > .Left > .Search > input[type="text"] { background: #1C1C1C; }');
addGlobalStyle('input { color: WHEAT; }');
addGlobalStyle('.SearchRadioButton > label { color: WHEAT; }');
addGlobalStyle('#SiteNavigationBar > .Right > .User > .Name, #SiteNavigationBar > .Right > .User > .SignOut { background: #1C1C1C; }');
addGlobalStyle('#SiteNavigationBar > .Right > .User > .Separator { background-color: #1C1C1C; }');
addGlobalStyle('#SiteNavigationBar > .Right > .User a.Button.Link { color: WHEAT; }');
addGlobalStyle('.CalendarContainer .Calendar .CalendarNavigation .Text { color: WHEAT; }');

// CONTAINERS & WIDGETS
addGlobalStyle('#DashboardContainer[data-background-theme="LightGray"], #DashboardContainer[data-background-theme="LightGray"] > .DashboardTabContainer { background: #1C1C1C; }');
addGlobalStyle('#DashboardContainer[data-background-theme="LightGray"] > .DashboardTitleBar > .DashboardButtonContainer > .DashboardTabButtonContainer > .Button.SelectedState { background-color: #1C1C1C; border-bottom-color: RED; }');
addGlobalStyle('#DashboardContainer[data-background-theme="LightGray"] > .DashboardTitleBar > .DashboardButtonContainer > .Button, #DashboardContainer[data-background-theme="LightGray"] > .DashboardTitleBar > .DashboardButtonContainer > .DashboardTabButtonContainer > .Button { background-color: #323232; color: WHEAT; }');
addGlobalStyle('#DashboardContainer[data-background-theme="LightGray"] > .DashboardTitleBar { border-bottom-color: #1C1C1C }');
addGlobalStyle('.WidgetShell > div > .Content { background: #1C1C1C; }');
addGlobalStyle('.Widget > .Title { background: #1C1C1C; color: WHITE; }');
addGlobalStyle('.Widget > .Content { background: #1C1C1C; }');
addGlobalStyle('.Widget > .Content > .GaugeTable > .GaugeColumn > .GaugeContainer > .GaugeTitle { color: WHITE; }');
addGlobalStyle('.ContextOverlay { border: 1px solid BLACK; }');
addGlobalStyle('.Widget > .Footer > .ContainerMenu { background: #1C1C1C; }');
addGlobalStyle('.Widget > .Content > .Total { color: WHITE; }');
addGlobalStyle('.Widget > .Content > .TableContainer > .Table .TableCell { color: WHITE; }');
addGlobalStyle('.Widget > .Content > .TableContainer > .Table .Amount { color: WHITE; }');
addGlobalStyle('.Widget > .Content > .TableContainer > .Table tr:nth-child(2n) { background-color: #4B4B4B; }');
addGlobalStyle('body.TechTheme .Grid .HeaderContainer, body .DashboardTab.TechTheme .Grid .HeaderContainer, body.TechTheme .Table .HeaderContainer, body .DashboardTab.TechTheme .Table .HeaderContainer { background: #4B4B4B; }');
addGlobalStyle('.Grid table { color: WHITE; }');
addGlobalStyle('#PageContainer { background: #1C1C1C; }');