// ==UserScript==
// @name         AUTOTASK - TIME ENTRY / SERVICE CALL
// @namespace    https://uk2.autotask.net/Mvc/Framework/Navigation.mvc/Landing
// @version      10.3
// @description  Dark Skin
// @author       schwarzerBengel
// @match        https://uk2.autotask.net/Autotask/views/ServiceDesk/*
// ==/UserScript==


/*
- DATE UPDATE -
2018.12.10

- NAMESPACE -

You must change the address according to your location.

Americ East: ww3.autotask.net
Americ East 2: ww14.autotask.net
America West: ww5.autotask.net
America West 2: ww15.autotask.net
UK (English Europe and Asia): ww4.autotask.net
UK 2 (English Europe and Asia): ww16.autotask.net
Australia / New Zealand: ww6.autotask.net
German (Deutsch: ww7.autotask.net
Spanish (Español): ww12.autotask.net

- SYNTAX -
addGlobalStyle(' { }');

- COLORS -
Background color : #1C1C1C
Grey : #4B4B4B
Pale grey : #323232
Pale yellow : WHEAT
*/

function addGlobalStyle(css) {
    var head, style;
    head = document.getElementsByTagName('head')[0];
    if (!head) { return; }
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = css;
    head.appendChild(style);
}

// BAR
addGlobalStyle('.atPageHeaderClass, tr.BlueberryPageHeader { background: #4B4B4B; }');
addGlobalStyle('.atPageHeaderClass span { color: WHEAT; }');

// BAR OF MENUS
addGlobalStyle('.ButtonCollectionBase, .datagrid .ButtonCollectionBase, .BlueberryMenuBar { background: #1C1C1C; }');
addGlobalStyle('.ButtonBase, .ButtonGradientGray { background: #1C1C1C; }');

// WRITING
addGlobalStyle('.Popup_Title { color: WHEAT; }');
addGlobalStyle('.Popup_Subtitle { color: WHITE !important; }');
addGlobalStyle('.DivSectionWithHeader > .HeaderRow > span { color: WHEAT !important; }');
addGlobalStyle('.lblNormalClass { color: WHITE !important; }');
addGlobalStyle('.FieldLabel, .workspace .FieldLabel, TABLE.FieldLabel TD, span.fieldlabel span label { color: WHITE !important; }');
addGlobalStyle('.txtBlack8Class { color: WHITE !important; }');
addGlobalStyle('.service_render_label { color: #666 !important; }');
addGlobalStyle('input[type="text"], select, textarea, input[type="password"] { color: WHEAT !important; }');

// BACKGROUND
addGlobalStyle('.DivScrollingContainer { background: #1C1C1C; }');
addGlobalStyle('input[type="text"], select, textarea, input[type="password"] { background: #1C1C1C; }');
addGlobalStyle('.DivSectionWithHeader.Collapsed > .HeaderRow { background: #1C1C1C; }');
addGlobalStyle('.DivSection .Collapsed, .DivSectionWithHeader.Collapsed { background: linear-gradient(to bottom,#1C1C1C 0,#1C1C1C 100%) !important; }');
addGlobalStyle('.ButtonCollectionBase, .datagrid .ButtonCollectionBase, .BlueberryMenuBar { background: #1C1C1C !important; }');
addGlobalStyle('body { background: #1C1C1C !important; }');