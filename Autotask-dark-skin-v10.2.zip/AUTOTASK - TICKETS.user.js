// ==UserScript==
// @name         AUTOTASK - TICKETS
// @namespace    https://uk2.autotask.net/Mvc/Framework/Navigation.mvc/Landing
// @version      10.2
// @description  Dark Skin
// @author       schwarzerBengel
// @match        https://uk2.autotask.net/Mvc/ServiceDesk/*
// ==/UserScript==


/*
- DATE UPDATE -
2018.12.10

- NAMESPACE -

You must change the address according to your location.

Americ East: ww3.autotask.net
Americ East 2: ww14.autotask.net
America West: ww5.autotask.net
America West 2: ww15.autotask.net
UK (English Europe and Asia): ww4.autotask.net
UK 2 (English Europe and Asia): ww16.autotask.net
Australia / New Zealand: ww6.autotask.net
German (Deutsch: ww7.autotask.net
Spanish (Español): ww12.autotask.net

- SYNTAX -
addGlobalStyle(' { }');

- COLORS -
Background color : #1C1C1C
Grey : #4B4B4B
Pale grey : #323232
Pale yellow : WHEAT
*/

function addGlobalStyle(css) {
    var head, style;
    head = document.getElementsByTagName('head')[0];
    if (!head) { return; }
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = css;
    head.appendChild(style);
}

// BAR
addGlobalStyle('.ToolBar { background: #1C1C1C; }');
addGlobalStyle('.ToolBar > .ToolBarItem > .Button, .ToolBar > .ToolBarItem > .DropDownButtonContainer, .ToolBar > .ToolBarItem > .DropDownButtonContainer > .Left > .Button, .ToolBar > .ToolBarItem > .DropDownButtonContainer > .Right > .Button.ToolBar > .ToolBarItem > .Button, .ToolBar > .ToolBarItem > .DropDownButtonContainer, .ToolBar > .ToolBarItem > .DropDownButtonContainer > .Left > .Button, .ToolBar > .ToolBarItem > .DropDownButtonContainer > .Right > .Button { background: #4b4b4b; }');
addGlobalStyle('.ToolBar > .ToolBarItem.Left.ButtonGroupEnd > .Button, .ToolBar > .ToolBarItem.Left.ButtonGroupEnd > .DropDownButtonContainer > .Right > .Button { border-right: 1px solid BLACK; }');
addGlobalStyle('.ToolBar > .ToolBarItem.Right.ButtonGroupStart > .Button, .ToolBar > .ToolBarItem.Right.ButtonGroupStart > .DropDownButtonContainer > .Left > .Button { border-left: 1px solid BLACK; }');

// LAUNCH BAR
addGlobalStyle('body.FullScroll > .QuickLaunchBar { background: #373E42; }');
addGlobalStyle('.QuickLaunchBar > .QuickLaunchButton > .Text { background: #373E42; }');

// LEFT SIDE PANEL
addGlobalStyle('body.EntityPage > .MainContainer > .SecondaryContainer { background: #1C1C1C; }');
addGlobalStyle('.DetailsSection > .Content > .ReadOnlyData > .LabelContainer { color: WHEAT; }');
addGlobalStyle('.DetailsSection > .Title { background-color: #4B4B4B; border-top: 1px solid BLACK; }');
addGlobalStyle('.DetailsSection > .Title > .Text { color: WHITE; }');
addGlobalStyle('.DetailsSection > .Content > .ReadOnlyData > .Value { color: WHITE; }');
addGlobalStyle('.EntityDetail > .MainContainer > .SecondaryContainer > .DetailsSection > .Content > .ReadOnlyData { background: #1C1C1C !important; }');

// CENTRAL PANEL
addGlobalStyle('body.EntityPage > .MainContainer > .PrimaryContainer { background: #1C1C1C; }');
addGlobalStyle('body.EntityPage > .MainContainer > .PrimaryContainer .HeadingContainer > .IdentificationContainer > .Left > .TypeName { color: WHEAT; }');
addGlobalStyle('body.EntityPage > .MainContainer > .PrimaryContainer .HeadingContainer > .IdentificationContainer > .Left > .IdentificationTextContainer > .IdentificationText { color: WHEAT; }');
addGlobalStyle('body.EntityPage > .MainContainer > .PrimaryContainer .HeadingContainer > .Title > .Text { color: WHITE; }');
addGlobalStyle('body.EntityPage > .MainContainer > .PrimaryContainer .HeadingContainer > .Bundle > div > .Text { color: WHEAT; }');
addGlobalStyle('body.EntityPage > .MainContainer > .PrimaryContainer > .AccessoryTabButtonBar > .Button.SelectedState { background: #4B4B4B; box-shadow: none !important; color: WHEAT; }');
addGlobalStyle('body.EntityPage > .MainContainer > .PrimaryContainer > .AccessoryTabButtonBar > .Button { background: #1C1C1C; color: WHEAT; border-top: 1px solid BLACK; border-bottom: 1px solid BLACK; }');
addGlobalStyle('.TabContainer > .ActivityTabShell > .Content .QuickNote > .Details textarea { background: #4B4B4B; border: 1px solid BLACK; box-shadow: none !important; }');
addGlobalStyle('select { background: #4B4B4B; color: WHITE;  }');
addGlobalStyle('input[type="text"], select, textarea { border: 1px solid BLACK; }');
addGlobalStyle('a.Button { border: 1px solid BLACK; background: #4B4B4B; }');
addGlobalStyle('.QuickNote .Editor.CheckBox .InputField > .EditorLabelContainer > .Label > label, .ActivityFilterContextOverlay .Editor.CheckBox .InputField > .EditorLabelContainer > .Label > label, .ActivityFilterBar .Editor.CheckBox .InputField > .EditorLabelContainer > .Label > label { color: WHEAT; }');
addGlobalStyle('.ActivityAdvancedOptions > input, .ActivityAdvancedOptions > select { background: #4B4B4B; color: WHITE;  }');
addGlobalStyle('.TabContainer > .ActivityTabShell > .Content > .Conversation > .ConversationChunk .ConversationItem > .Details > .Header > .Participants > .Author > a.Button.Link.DisabledState, .TabContainer > .ActivityTabShell > .Content > .Conversation > .ConversationChunk .ConversationItem > .Details > .Header > .Participants > .ReplyTo > a.Button.Link.DisabledState { color: WHEAT; }');
addGlobalStyle('.TabContainer > .ActivityTabShell > .Content > .Conversation > .ConversationChunk .ConversationItem > .Details > .Title, .TabContainer > .ActivityTabShell > .Content > .Conversation > .ConversationChunk .ConversationItem > .Details > .Title > .Text > a.Button.Link { color: WHITE; }');
addGlobalStyle('.TabContainer > .ActivityTabShell > .Content > .Conversation > .ConversationChunk .ConversationItem > .Details > .Message { font-style: italic; color: WHITE; }');
addGlobalStyle('.EntityBodyEnhancedText > .Content, .EntityBodyEnhancedText > .Indicator, .EntityBodyEnhancedText > .ContentRemaining { color: WHITE; }');

//RIGHT PANEL
addGlobalStyle('.InsightShell { background: #4B4B4B; border: 1px solid BLACK; }');
addGlobalStyle('.InsightShell > .Title > .Text { color: white; }');
addGlobalStyle('.InsightShell > .ContentContainer > .Content { background: #1C1C1C; }');
addGlobalStyle('.InsightShell > .ContentContainer > .Content .Text:not(.ColorText) { color: WHEAT; }');

// TIMER
addGlobalStyle('.StopwatchContainer { background-color: #4b4b47; border: 2px solid BLACK; }');

// EDITING TICKETS
addGlobalStyle('input { background: #4B4B4B; color: WHITE; }');
addGlobalStyle('.Item > div.Text { color: WHEAT; }');
addGlobalStyle('body.EntityPage > .MainContainer > .PrimaryContainer .HeadingContainer > .Editor.AdjustingTextBox { color: WHITE; }');