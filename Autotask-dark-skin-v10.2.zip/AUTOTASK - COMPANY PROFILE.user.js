// ==UserScript==
// @name         AUTOTASK - COMPANY PROFILE
// @namespace    https://uk2.autotask.net/Mvc/Framework/Navigation.mvc/Landing
// @version      10.2
// @description  Dark Skin
// @author       schwarzerBengel
// @match        https://uk2.autotask.net/Autotask35/crm/account/*
// ==/UserScript==


/*
- DATE UPDATE -
2018.12.10

- NAMESPACE -

You must change the address according to your location.

Americ East: ww3.autotask.net
Americ East 2: ww14.autotask.net
America West: ww5.autotask.net
America West 2: ww15.autotask.net
UK (English Europe and Asia): ww4.autotask.net
UK 2 (English Europe and Asia): ww16.autotask.net
Australia / New Zealand: ww6.autotask.net
German (Deutsch: ww7.autotask.net
Spanish (Español): ww12.autotask.net

- SYNTAX -
addGlobalStyle(' { }');

- COLORS -
Background color : #1C1C1C
Grey : #4B4B4B
Pale grey : #323232
Pale yellow : WHEAT
*/

function addGlobalStyle(css) {
    var head, style;
    head = document.getElementsByTagName('head')[0];
    if (!head) { return; }
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = css;
    head.appendChild(style);
}

// BAR
addGlobalStyle('body.TechTheme .pageTitleBar, body.TechTheme .headerPanel { background: #4B4B4B !important; }');
addGlobalStyle('body.TechTheme .pageTitleBar span { color: WHEAT !important; }');

// BACKGROUND
addGlobalStyle('html, form { background: #1C1C1C !important; }');
addGlobalStyle('.CommentTextBoxNoFocus { background: #4B4B4B !important; }');
addGlobalStyle('input[type="text"], input[type="password"], select, textarea { color: WHITE; background: #4B4B4B !important; }');
addGlobalStyle('.EntityFeedLevel2 { background: #1C1C1C !important; }');
addGlobalStyle('.DivSectionWithColor { background: #1C1C1C !important; }');

// BAR OF MENUS
addGlobalStyle('#TopMenuContainer { background: #1C1C1C !important; }');
addGlobalStyle('.MainTopMenuItem { background: #1C1C1C !important; }');

// WRITING
addGlobalStyle('.SubtitleDiv { color: WHITE; }');
addGlobalStyle('.labelGray, .tableCell span.labelText { color: WHITE; }');
addGlobalStyle('.labelBlack, .tableCell { color: WHITE; }');
addGlobalStyle('body { color: WHITE !important; }');
addGlobalStyle('.LabelBold { color: WHEAT !important; }');
addGlobalStyle('.label { color: WHEAT !important; }');