// ==UserScript==
// @name         AUTOTASK - CALENDAR
// @namespace    https://uk2.autotask.net/Mvc/Framework/Navigation.mvc/Landing
// @version      10.2
// @description  Dark Skin
// @author       schwarzerBengel
// @match        https://uk2.autotask.net/Autotask/Views/DispatcherWorkshop/*
// ==/UserScript==

/*
- DATE UPDATE -
2018.12.10

- NAMESPACE -

You must change the address according to your location.

Americ East: ww3.autotask.net
Americ East 2: ww14.autotask.net
America West: ww5.autotask.net
America West 2: ww15.autotask.net
UK (English Europe and Asia): ww4.autotask.net
UK 2 (English Europe and Asia): ww16.autotask.net
Australia / New Zealand: ww6.autotask.net
German (Deutsch: ww7.autotask.net
Spanish (Español): ww12.autotask.net

- SYNTAX -
addGlobalStyle(' { }');

- COLORS -
Background color : #1C1C1C
Grey : #4B4B4B
Pale grey : #323232
Pale yellow : WHEAT
*/

function addGlobalStyle(css) {
    var head, style;
    head = document.getElementsByTagName('head')[0];
    if (!head) { return; }
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = css;
    head.appendChild(style);
}

// BAR
addGlobalStyle('.atPageHeaderClass, tr.BlueberryPageHeader { background-color: #4b4b4b !important; }');
addGlobalStyle('.atPageHeaderClass span { color: wheat !important; }');
addGlobalStyle('.ButtonCollectionBase, .datagrid .ButtonCollectionBase, .BlueberryMenuBar { background-color: #1c1c1c !important; }');
addGlobalStyle('.ButtonBase, .ButtonGradientGray { background: #4b4b4b !important; }');
addGlobalStyle('.ButtonBase .ButtonText, .BlueBerryMenuBar .BlueberryButton .ButtonText, .ButtonBaseDark .ButtonText, .ButtonGradientGray .ButtonText { color: white !important; }');
addGlobalStyle('.lblNormalClass { color: white !important; }');
addGlobalStyle('.txtBlack8Class { color: white !important; }');

// TABLEAU
addGlobalStyle('table.Grid tr td.BodyLockedColumns div { background-color: #1C1C1C; }');
addGlobalStyle('table.Grid tr td.HeadFloatColumns div { background-color: #4B4B4B; }');
addGlobalStyle('table.Grid tr td.HeadLockedColumns div { background-color: #4B4B4B; }');
addGlobalStyle('.Grid1_Container_Head_Column_Date { background-color: BLACK; }');
addGlobalStyle('table.ActivityBlock, .Grid1_Container_Head_Column_Name div { background-color: #4B4B4B; }');
addGlobalStyle('table.ActivityBlock td.Rate49 { background-color: BLACK; }');
addGlobalStyle('table.Grid { border-color: black; }');

// APPOINTEMENT
addGlobalStyle('div.APPOINTMENTHOURLY { background-color: #EEFEF0 !important; }');
addGlobalStyle('div.APPOINTMENTHOURLY { border-bottom: 1px solid black !important; }');
addGlobalStyle('div.APPOINTMENTHOURLY { border-top: 1px solid black !important; }');
addGlobalStyle('div.APPOINTMENTHOURLY { border-left: 1px solid black !important; }');
addGlobalStyle('div.APPOINTMENTHOURLY { border-right: 1px solid black !important; }');
addGlobalStyle('div.APPOINTMENTHOURLY { color: black !important; }');
addGlobalStyle('div.APPOINTMENTHOURLY { font-style: italic !important; }');

// SERVICE CALL
addGlobalStyle('div.SERVICECALL { color: white !important; }');
addGlobalStyle('div.SERVICECALL { border-bottom: 1px solid black !important; }');
addGlobalStyle('div.SERVICECALL { border-top: 1px solid black !important; }');
addGlobalStyle('div.SERVICECALL { background-color: #484747 !important; }');

// CLICK RIGHT
addGlobalStyle('.RightClickMenu { background-color: #4b4b4b !important; border: solid 1px black; }');


